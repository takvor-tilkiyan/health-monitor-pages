import os
import json
import re
import traceback
from base64 import b64encode
from gpiozero import LED
from time import sleep
from datetime import datetime
from datetime import timedelta
from getpass import getpass
from urllib.request import urlopen
from urllib.request import Request
from urllib.parse import urlencode
from urllib.error import URLError


def get_access_token(token_url, client_id, client_secret):
  body_text = {"grant_type" : "client_credentials"}
  body_url_encoded = urlencode(body_text)
  body_bytes = bytes(body_url_encoded, UTF_8)

  token_request = Request(token_url, body_bytes)

  cred_bytes = bytes(client_id + ":" + client_secret, UTF_8)
  cred_base_64 = b64encode(cred_bytes)
  token_request.add_header("Authorization", "Basic " + cred_base_64.decode(UTF_8))
  token_request.add_header("Content-Type", "application/x-www-form-urlencoded")

  try:
    token_response = urlopen(token_request)
    token_response_bytes = token_response.read()
    token_response_str = token_response_bytes.decode(UTF_8)
    token_response_json = json.loads(token_response_str)

    return token_response_json["access_token"]
  except (URLError, ConnectionError) as e:
    print("An error was raised when getting access token at " + datetime.now().isoformat() + ":")
    print("Error: " + str(e))
    traceback.print_exc()
    

def get_health(health_check_url, access_token):
  health_request = Request(health_check_url)
  health_request.add_header("Authorization", "Bearer " + access_token)

  try:
    health_response = urlopen(health_request)
    health_response_bytes = health_response.read()

    return health_response_bytes.decode(UTF_8)
  except (URLError, ConnectionError) as e:
    print("An error was raised when getting health at " + datetime.now().isoformat() + ":")
    print("Error: " + str(e))
    traceback.print_exc()

def check_health(health_result, success_regex):
  is_success = bool(re.search(success_regex, health_result))
  print("Success regex in health response at " + datetime.now().isoformat() + ": " + str(is_success))
  return is_success

def signal_health_problem():
  print("Flashing LED to signal health problem at " + datetime.now().isoformat())
  led.blink()
  
UTF_8 = "utf-8"
HEARTBEAT_MINUTE_OF_HOUR = 0
HEARTBEAT_SLEEP_SECONDS = 55

try:
  health_check_url = input("Health check URL: ")
  success_regex = input("Success regex: ")
  token_url = input("Token URL: ")
  client_id = input("Client ID: ")
  client_secret = getpass("Client secret: ")
  regular_check_cycle_seconds = int(input("Regular check cycle (seconds): "))
  error_check_cycle_seconds = int(input("Error check cycle (seconds): "))
  os.system("cls" if os.name == "nt" else "reset")

  is_healthy = True
  heartbeat_hour = datetime.now().hour - 1
  led = LED(24)

  while True:
    check_cycle_seconds = regular_check_cycle_seconds if is_healthy else error_check_cycle_seconds
    check_start = datetime.now()
    print("Starting health check in a " + str(check_cycle_seconds) + " seconds cycle at " + datetime.now().isoformat())

    while datetime.now() - check_start < timedelta(seconds=check_cycle_seconds):
      if is_healthy and datetime.now().minute == HEARTBEAT_MINUTE_OF_HOUR and datetime.now().hour != heartbeat_hour:
        print("Flashing LED once as a heartbeat check for this script at " + datetime.now().isoformat())
        led.blink(n=1)
        heartbeat_hour = datetime.now().hour
      sleep(HEARTBEAT_SLEEP_SECONDS if check_cycle_seconds > HEARTBEAT_SLEEP_SECONDS else check_cycle_seconds)

    access_token = get_access_token(token_url, client_id, client_secret)
    if access_token is None:
      is_healthy = False
      signal_health_problem()
      continue

    health_result = get_health(health_check_url, access_token)
    if health_result is None:
      is_healthy = False
      signal_health_problem()
      continue

    if not check_health(health_result, success_regex):
      is_healthy = False
      signal_health_problem()
      continue

    is_healthy = True

    print("Turning off LED after checking that health is OK at " + datetime.now().isoformat())
    led.off()


except KeyboardInterrupt:
  print("Cleaning up at " + datetime.now().isoformat())

  print("Turning led off at " + datetime.now().isoformat())
  led.off()
